import { Component } from '@angular/core';


@Component({
  selector: 'bs-navbar',
  templateUrl: './bs-navbar.component.html',
})
export class BsNavbarComponent {

  
  constructor() {
   }

  logout() {

  }
}
